﻿
using Microservices.Monolithic.Application.Models;

namespace Microservices.Monolithic.Application.Helper
{
    public static class EmailSender
    {
        public static void SendEmailToDispatch(Order order)
        {
            
        }
    }
}
