﻿
using Microservices.SOA.Service.Models;

namespace Microservices.SOA.Service.Helper
{
    public static class EmailSender
    {
        public static void SendEmailToDispatch(Order order)
        {
            
        }
    }
}
